import { DefectPipe } from './defect.pipe';

describe('DefectPipe', () => {
  it('create an instance', () => {
    const pipe = new DefectPipe();
    expect(pipe).toBeTruthy();
  });
});
