import { MispipePipe } from './mispipe.pipe';

describe('MispipePipe', () => {
  it('create an instance', () => {
    const pipe = new MispipePipe();
    expect(pipe).toBeTruthy();
  });
});
