import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misdashboard',
  templateUrl: './misdashboard.component.html',
  styleUrls: ['./misdashboard.component.scss']
})
export class MISDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
