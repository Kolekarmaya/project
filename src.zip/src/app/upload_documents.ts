export const documents = ['CSSRC', 'LIVE', 'TC', 'Batch Time']
